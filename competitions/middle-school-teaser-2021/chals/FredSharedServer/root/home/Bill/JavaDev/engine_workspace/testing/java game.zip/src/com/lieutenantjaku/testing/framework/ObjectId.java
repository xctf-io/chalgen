package com.lieutenantjaku.testing.framework;

public enum ObjectId {

	Player(),
	Block(),
	Test();
	
}
